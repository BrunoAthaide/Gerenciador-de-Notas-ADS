package com.example.trabalhomobile;

import android.os.Bundle;
import android.text.TextUtils;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.regex.Pattern;


public class CalcularNotas extends AppCompatActivity {

    private EditText etNome, etEmail, etIdade, etDisciplina, etNota1, etNota2;
    private ListView lvResultados;
    private Button btnCalcular, btnLimpar;
    private ArrayList<String> resultados;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeViews();
        configureListView();
        setupButtonListeners();
    }

    private void initializeViews() {
        etNome = findViewById(R.id.etNome);
        etEmail = findViewById(R.id.etEmail);
        etIdade = findViewById(R.id.etIdade);
        etDisciplina = findViewById(R.id.etDisciplina);
        etNota1 = findViewById(R.id.etNota1);
        etNota2 = findViewById(R.id.etNota2);
        lvResultados = findViewById(R.id.lvResultados);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnLimpar = findViewById(R.id.btnLimpar);
    }

    private void configureListView() {
        resultados = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, resultados);
        lvResultados.setAdapter(adapter);
    }

    private void setupButtonListeners() {
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    calculateAverage();
                }
            }
        });

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearFields();
            }
        });
    }

    private void calculateAverage() {
        double nota1 = Double.parseDouble(etNota1.getText().toString());
        double nota2 = Double.parseDouble(etNota2.getText().toString());
        double media = (nota1 + nota2) / 2;

        String status = media >= 60 ? "Aprovado" : "Reprovado";
        String resultado = String.format("Nome: %s\nEmail: %s\nIdade: %s\nDisciplina: %s\nMédia: %.2f\nStatus: %s",
                etNome.getText().toString(), etEmail.getText().toString(), etIdade.getText().toString(),
                etDisciplina.getText().toString(), media, status);

        resultados.add(resultado);
        adapter.notifyDataSetChanged();
    }

    private void clearFields() {
        etNome.setText("");
        etEmail.setText("");
        etIdade.setText("");
        etDisciplina.setText("");
        etNota1.setText("");
        etNota2.setText("");
    }

    private boolean validateInputs() {
        if (TextUtils.isEmpty(etNome.getText()) || !isNomeValido(etNome.getText().toString())) {
            etNome.setError("O nome deve conter apenas letras");
            return false;
        }
        if (TextUtils.isEmpty(etEmail.getText()) || !android.util.Patterns.EMAIL_ADDRESS.matcher(etEmail.getText()).matches()) {
            etEmail.setError("Email inválido");
            return false;
        }
        if (TextUtils.isEmpty(etIdade.getText()) || !isAgeValid(etIdade.getText().toString())) {
            etIdade.setError("Idade deve ser entre 1 e 120");
            return false;
        }
        if (!areNotasValidas()) {
            return false;
        }
        return true;
    }

    private boolean isNomeValido(String nome) {
        // validar qualquer coisa que não seja letra ( No campo Nome )
        return Pattern.matches("[a-zA-ZÀ-ÿ\\s]+", nome);
    }

    private boolean isAgeValid(String ageString) {
        int age = Integer.parseInt(ageString);
        return age > 0 && age <= 120;
    }

    private boolean areNotasValidas() {
        if (TextUtils.isEmpty(etNota1.getText()) || !isNotaValida(etNota1.getText().toString())) {
            etNota1.setError("Nota deve estar entre 0 e 100");
            return false;
        }
        if (TextUtils.isEmpty(etNota2.getText()) || !isNotaValida(etNota2.getText().toString())) {
            etNota2.setError("Nota deve estar entre 0 e 100");
            return false;
        }
        return true;
    }

    private boolean isNotaValida(String notaString) {
        double nota = Double.parseDouble(notaString);
        return nota >= 0 && nota <= 100;
    }
}